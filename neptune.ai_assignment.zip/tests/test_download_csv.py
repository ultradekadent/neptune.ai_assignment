import pytest, re, os, csv
from playwright.sync_api import expect
from pages.single_run import Attributes


@pytest.mark.attributes_download_csv
@pytest.mark.flaky(retries=3, delay=5)
def test_download_csv(page):
    attr_selectors=Attributes(page)

    # Assert that the 'Attributes' tab is visible within 10 seconds.
    expect(attr_selectors.attributes_tab).to_be_visible(timeout=10_000)

    # Navigate to known namespace & attribute
    attr_selectors.eval_namespace.click()

    attr_selectors.metrics_namespace.click()

    attr_selectors.loss_attr.click()

    # Assert that the 'Download' button is visible within 5 seconds.
    expect(attr_selectors.download_btn).to_be_visible()

    # Start waiting for the download
    with page.expect_download() as download_info:
        # Perform the action that initiates download.
        attr_selectors.download_btn.click()

        attr_selectors.download_as_csv_btn.click()

        download = download_info.value

        # Verify file name and extension
        assert re.match("eval_metrics_loss.csv", download.suggested_filename)

        file_name = download.suggested_filename # <-- maintaining original file name for verification
        destination_folder_path = "test_files"
        file = (os.path.join(destination_folder_path, file_name))
        download.save_as(file)

        # Inspect the downloaded CSV file
        rows = []    # Data rows

        with open(file, 'r') as csvfile:
            # Create CSV reader object
            csvreader = csv.reader(csvfile)

            # Read rows
            for row in csvreader:
                rows.append(row)

            # Print total row count
            print("Total no. of rows: %d" % csvreader.line_num)

            # Print the first 5 rows
            print('\nFirst 5 rows are:\n')
            for row in rows[:5]:
                for col in row:
                    print("%10s" % col, end=" ")
                print('\n')
    